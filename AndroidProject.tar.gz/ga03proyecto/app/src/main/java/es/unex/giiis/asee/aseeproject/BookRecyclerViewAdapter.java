package es.unex.giiis.asee.aseeproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import es.unex.giiis.asee.aseeproject.BookFragment.OnListFragmentInteractionListener;
import es.unex.giiis.asee.aseeproject.models.BookItem;

/**
 * {@link RecyclerView.Adapter} that can display a {@link BookItem} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class BookRecyclerViewAdapter extends RecyclerView.Adapter<BookRecyclerViewAdapter.ViewHolder> {

    private final List<BookItem> mValues;
    private final OnListFragmentInteractionListener mListener;
    private Context mContext;

    public BookRecyclerViewAdapter(Context context, List<BookItem> items, OnListFragmentInteractionListener listener) {
        mContext = context;
        mValues = items;
        mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_book, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        //TODO - Cambiar movie-poster por la imagen obtenida de la API
        holder.mImageView.setImageDrawable(mContext.getDrawable(R.drawable.movie_poster));

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onListFragmentInteraction(holder.mItem);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final ImageView mImageView;
        public BookItem mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mImageView = (ImageView) view.findViewById(R.id.iv_book_item_list_poster);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mItem.getbID() + "'";
        }
    }
}
