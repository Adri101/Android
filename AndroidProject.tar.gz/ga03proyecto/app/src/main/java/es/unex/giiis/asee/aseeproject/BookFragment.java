package es.unex.giiis.asee.aseeproject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import es.unex.giiis.asee.aseeproject.database.BookFavouriteCRUD;
import es.unex.giiis.asee.aseeproject.database.BookItemCRUD;
import es.unex.giiis.asee.aseeproject.database.DBContract;
import es.unex.giiis.asee.aseeproject.models.BookItem;
import es.unex.giiis.asee.aseeproject.models.Bookshelf;
import es.unex.giiis.asee.aseeproject.models.Item;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/*
    Steps:
    * Create empty project
    * Declare INTERNET permission
    * Add dependencies:
        - com.squareup.retrofit2
        - com.squareup.retrofit2:converter-gson
    * Add pojos: Bookshelf from jsonschema2pojo
    * Define service interface
    * Create REST adapter
    * Create a service implementation
    * Create a call
    * Use the call async'ly
        - define callbacks: onReponse & onFailure
 */

/**
 * A fragment representing a list of Items.
 * <p/>
 */
public class BookFragment extends Fragment implements MyAdapter.OnListInteractionListener{

    //Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    //Customize parameters
    private int mColumnCount = 3;
    private OnListFragmentInteractionListener mListener;
    private MyAdapter mAdapter;


    @Override
    public void onListInteraction(BookItem bookItem) {
        Intent intent = new Intent(getContext(), BookDetailsActivity.class);
        intent.putExtra("bookItem", bookItem.getbIsbn());
        startActivity(intent);
    }

    public interface GoogleBooks {
        @GET("users/{user}/bookshelves/{coleccion}/volumes")
        Call<Bookshelf> listRepos(@Path("user") String user, @Path("coleccion") Integer coleccion, @Query("maxResults") Integer maxResults, @Query("key") String key);

    }



    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public BookFragment() {
    }

    //Customize parameter initialization
    @SuppressWarnings("unused")
    public static BookFragment newInstance(int columnCount) {
        BookFragment fragment = new BookFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_book_list, container, false);

        // Set the adapter
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            RecyclerView recyclerView = (RecyclerView) view;

            recyclerView.setLayoutManager(new GridLayoutManager(context, 3));

            List<BookItem> myDataset = new ArrayList<BookItem>();
            mAdapter = new MyAdapter(myDataset, this, context);
            recyclerView.setAdapter(mAdapter);


            /*
            if (mColumnCount <= 1) {
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
            } else {
                recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
            }
            */

            // Create a very simple REST adapter which points the API.
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("https://www.googleapis.com/books/v1/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            // Create an instance of our GitHub API interface.
            GoogleBooks service = retrofit.create(GoogleBooks.class);

            // Create a call instance for looking up repos.
            Call <Bookshelf> call = service.listRepos("109713644623575462613", 0, 40,"AIzaSyCTjTcgoHKX_DIUpFcNMUzclKzaWpG5CPM");

            Log.i("Tag", "Estoy antes de enque()");
            // Fetch and print a list of the contributors to the library.
            // Async call
            call.enqueue(new Callback<Bookshelf>() {
                @Override
                public void onResponse(Call<Bookshelf> call, Response<Bookshelf>response) {
                    Log.i("Tag", "Estoy en onResponse()");
                    if (response.isSuccessful()) {
                        // tasks available
                        Bookshelf items = response.body(); //para parsear creo la lista de objetos vols

                        //Guardarlos en la bd
                        saveAllBooks(items);


                        Log.i("Retrofit101", "Voy a procesar los libros");
                        for (Item item : items.getItems()) {
                            Log.i("Retrofit101","name: "+item.getVolumeInfo().getTitle());
                        }
                    } else {
                        // error response, no access to resource?
                        Log.d("Retrofit101", "RESPONSE NO OK");
                    }
                }

                @Override
                public void onFailure(Call<Bookshelf> call, Throwable t) {
                    // something went completely south (like no internet connection)
                    Log.d("Error", t.getMessage());
                }
            });

            if (((MainActivity) getActivity()).getCurrentFragment() == 3) {
                BookFavouriteCRUD bookFavouriteCRUD = BookFavouriteCRUD.getInstance(mAdapter.getContext());
                mAdapter.swap(bookFavouriteCRUD.getAll());
                ((MainActivity) getActivity()).setCurrentFragment(0);
            }
            else if (((MainActivity) getActivity()).getCurrentFragment() == 2){
                Bundle bundle = getArguments();
                String categoryName = bundle.getSerializable("categoryName").toString();

                BookItemCRUD bookItemCRUD = BookItemCRUD.getInstance(mAdapter.getContext());
                mAdapter.swap(bookItemCRUD.getByCategory(categoryName));
                ((MainActivity) getActivity()).setCurrentFragment(0);
            } else {
                BookItemCRUD bookItemCRUD = BookItemCRUD.getInstance(mAdapter.getContext());
                mAdapter.swap(bookItemCRUD.getAll());
            }


        }
        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnListFragmentInteractionListener {
        // TODO: Update argument type and name
        void onListFragmentInteraction(BookItem item);
    }

    public void saveAllBooks(Bookshelf books){
        BookItemCRUD bookItemCRUD = BookItemCRUD.getInstance(this.getContext());

        long idLibro = 0;
        List<BookItem> bookitems = new ArrayList<>();

        //Conversion de Item (Api) a BookItem (Clase modelo para un libro)
        for(Item i: books.getItems()){
            bookitems.add(itemToBookItem(i, idLibro));
            idLibro ++;
        }
        bookItemCRUD.deleteAll();
        for (BookItem b : bookitems){
            bookItemCRUD.insert(b);
        }
    }

    /**
     * Convierte la información de un libro obtenida de la API, a una instancia de BookItem
     * @param item
     * @return
     */
    public BookItem itemToBookItem (Item item, long idLibro){
        BookItem bookItem;

        SimpleDateFormat FORMAT = new SimpleDateFormat(
                "yyyy-mm-dd", Locale.US);

        String ID = item.getId();
        String title = item.getVolumeInfo().getTitle();
        String isbn = item.getVolumeInfo().getIndustryIdentifiers().get(0).getIdentifier();
        String author = item.getVolumeInfo().getAuthors().get(0);
        String publishDate = item.getVolumeInfo().getPublishedDate(); // Revisar
        String synopsis = item.getVolumeInfo().getDescription();
        String category = item.getVolumeInfo().getCategories().get(0);
        String image = item.getVolumeInfo().getImageLinks().getSmallThumbnail();

        bookItem = new BookItem(idLibro,title,isbn,author,publishDate,synopsis,category,image);

        return bookItem;
    }
}
