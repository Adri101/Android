
package es.unex.giiis.asee.aseeproject.models;

import com.google.gson.annotations.Expose;

import java.util.List;

public class Bookshelf {

    @Expose
    private String kind;
    @Expose
    private Integer totalItems;
    @Expose
    private List<Item> items = null;

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public Integer getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(Integer totalItems) {
        this.totalItems = totalItems;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

}
