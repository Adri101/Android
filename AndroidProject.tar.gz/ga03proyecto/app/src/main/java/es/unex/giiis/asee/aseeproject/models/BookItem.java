package es.unex.giiis.asee.aseeproject.models;

import android.content.Intent;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BookItem implements Serializable {

    public final static String ID = "ID";
    public final static String TITLE = "title";
    public final static String AUTHOR = "author";
    public final static String ISBN = "isbn";
    public final static String PUBLISHDATE = "publishdate";
    public final static String SYNOPSIS = "synopsis";
    public final static String CATEGORY = "category";
    public final static String IMAGE = "image";

    public final static SimpleDateFormat FORMAT = new SimpleDateFormat(
            "yyyy", Locale.US);

    private long bID;
    private String bTitle;
    private String bAuthor;
    private String bIsbn;
    private Date bPublishDate = new Date();
    private String bSynopsis;
    private String bCategory;
    private String bImage;

    public BookItem(long bID, String bTitle, String bIsbn, String bAuthor, Date bPublishDate, String bSynopsis, String bCategory, String bImage) {
        this.bID = bID;
        this.bTitle = bTitle;
        this.bAuthor = bAuthor;
        this.bIsbn = bIsbn;
        this.bPublishDate = bPublishDate;
        this.bSynopsis = bSynopsis;
        this.bCategory = bCategory;
        this.bImage = bImage;
    }
    public BookItem(long bID, String bTitle, String bIsbn, String bAuthor, String publishDate, String bSynopsis, String bCategory, String bImage) {
        this.bID = bID;
        this.bTitle = bTitle;
        this.bIsbn = bIsbn;
        this.bAuthor = bAuthor;
        try {
            bPublishDate = BookItem.FORMAT.parse(publishDate);
        } catch(ParseException e){
            bPublishDate = new Date();
        }
        this.bSynopsis = bSynopsis;
        this.bCategory = bCategory;
        this.bImage = bImage;
    }

    BookItem(Intent intent){
        bID = intent.getLongExtra(BookItem.ID, 0);
        bTitle = intent.getStringExtra(BookItem.TITLE);
        bAuthor = intent.getStringExtra(BookItem.AUTHOR);
        bIsbn = intent.getStringExtra(BookItem.ISBN);

        try{
            bPublishDate = BookItem.FORMAT.parse(intent.getStringExtra(BookItem.PUBLISHDATE));
        }
        catch (ParseException e){
            bPublishDate = new Date();
        }

        bSynopsis = intent.getStringExtra(BookItem.SYNOPSIS);
        bCategory = intent.getStringExtra(BookItem.CATEGORY);
        bImage = intent.getStringExtra(BookItem.IMAGE);

    }

    public long getbID() {
        return bID;
    }

    public void setbID(long bID) {
        this.bID = bID;
    }

    public String getbTitle() {
        return bTitle;
    }

    public void setbTitle(String bTitle) {
        this.bTitle = bTitle;
    }

    public String getbAuthor() {
        return bAuthor;
    }

    public void setbAuthor(String bAuthor) {
        this.bAuthor = bAuthor;
    }

    public String getbIsbn() {
        return bIsbn;
    }

    public void setbIsbn(String bIsbn) {
        this.bIsbn = bIsbn;
    }

    public Date getbPublishDate() {
        return bPublishDate;
    }

    public void setbPublishDate(Date bPublishDate) {
        this.bPublishDate = bPublishDate;
    }

    public String getbSynopsis() {
        return bSynopsis;
    }

    public void setbSynopsis(String bSynopsis) {
        this.bSynopsis = bSynopsis;
    }

    public String getbCategory() {
        return bCategory;
    }

    public void setbCategory(String bCategory) {
        this.bCategory = bCategory;
    }

    public String getbImage() {
        return bImage;
    }

    public void setbImage(String bImage) {
        this.bImage = bImage;
    }

    public static void packageIntent (Intent intent, String bTitle, String bAuthor, String bIsbn, String publishDate, String bSynopsis, String bCategory, String bImage){
        intent.putExtra(BookItem.TITLE, bTitle);
        intent.putExtra(BookItem.AUTHOR, bAuthor);
        intent.putExtra(BookItem.ISBN, bIsbn);
        intent.putExtra(BookItem.PUBLISHDATE, publishDate);
        intent.putExtra(BookItem.SYNOPSIS, bSynopsis);
        intent.putExtra(BookItem.CATEGORY, bCategory);
        intent.putExtra(BookItem.IMAGE, bImage);
    }

    @Override
    public String toString() {
        return "BookItem{" +
                "bID=" + bID +
                ", bTitle='" + bTitle + '\'' +
                ", bAuthor='" + bAuthor + '\'' +
                ", bIsbn='" + bIsbn + '\'' +
                ", bPublishDate=" + bPublishDate +
                ", bSynopsis='" + bSynopsis + '\'' +
                ", bCategory='" + bCategory + '\'' +
                ", bImage='" + bImage + '\'' +
                '}';
    }
}
