package es.unex.giiis.asee.aseeproject;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;

import java.util.List;

import es.unex.giiis.asee.aseeproject.database.BookFavouriteCRUD;
import es.unex.giiis.asee.aseeproject.database.BookItemCRUD;
import es.unex.giiis.asee.aseeproject.models.BookItem;

public class BookDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);

        ActionBar ab = getSupportActionBar();

        String isbn = getIntent().getStringExtra("bookItem");
        Log.i("ISBN BDActivity", isbn);
        BookItemCRUD bookItemCRUD = BookItemCRUD.getInstance(this);
        List<BookItem> libros = bookItemCRUD.getByIsbn(isbn);

        BookDetailsFragment bookDetailsFragment = new BookDetailsFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        Bundle bundle = new Bundle();
        Log.i("GET(0)", libros.get(0).getbIsbn());
        bundle.putSerializable("bookItem", libros.get(0));
        bookDetailsFragment.setArguments(bundle);

        fragmentTransaction.add(R.id.fragment_container_details, bookDetailsFragment);
        //fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

        ab.setDisplayHomeAsUpEnabled(true);
        ab.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.darkerGray)));
        ab.setTitle(R.string.app_name);
    }

}
